<!-- Thanks for submitting an issue! All bug reports and problem issues require a **reduced test case**. Create one forking the JSFiddle linked below. See the guidelines link above for more details. -->

**Test case:** https://jsfiddle.net/cferdinandi/87v3pqp0/